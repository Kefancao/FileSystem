#ifndef __EXCEPTION_H__
#define __EXCEPTION_H__

// Exception classes for different types of errors.

class NoRoomException{}; 

class NoMatchException{}; 

class DuplicateFileException{};

#endif
